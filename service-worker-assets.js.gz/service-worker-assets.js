﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-9ii4qjKGPvpLTaicCQnJv0mciOW8fP4btmKpFYjgN78=",
      "url": "_content\/Tewr.Blazor.FileReader\/FileReaderComponent.js"
    },
    {
      "hash": "sha256-eeZxFDw9wtGefPyX5fYtEPuCS\/VyBK8\/FfeXUOo5zF4=",
      "url": "_content\/Tewr.Blazor.FileReader\/FileReaderComponent.js.map"
    },
    {
      "hash": "sha256-BHNhq10T\/9aejlrFEhS\/NYeYS3Djwv\/pqg2xUjQCx\/s=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-rldnE7wZYJj3Q43t5v8fg1ojKRwyt0Wtfm+224CacZs=",
      "url": "css\/bootstrap\/bootstrap.min.css"
    },
    {
      "hash": "sha256-xMZ0SaSBYZSHVjFdZTAT\/IjRExRIxSriWcJLcA9nkj0=",
      "url": "css\/bootstrap\/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-jA4J4h\/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "css\/open-iconic\/FONT-LICENSE"
    },
    {
      "hash": "sha256-BJ\/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css\/open-iconic\/font\/css\/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh\/chSkSvQpc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv\/U1xl\/9D3ehyU69JE+FvAcu5HQ+\/a0=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ\/v\/QzXlejRDwUNdZIofI=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.woff"
    },
    {
      "hash": "sha256-aF5g\/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU\/ss=",
      "url": "css\/open-iconic\/ICON-LICENSE"
    },
    {
      "hash": "sha256-p\/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA\/tb0=",
      "url": "css\/open-iconic\/README.md"
    },
    {
      "hash": "sha256-XqBnMoHlA7OEFf6Q\/u1QuwzEdspsEYCgpZCqaxxN4H0=",
      "url": "css\/prism.css"
    },
    {
      "hash": "sha256-qU+KhVPK6oQw3UyjzAHU4xjRmCj3TLZUU\/+39dni9E0=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-IpHFcQvs03lh6W54zoeJRG1jW+VnGmwymzxLoXtKX7Y=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-NT+ke3BdjaozlB0NnVb87kE8wTBnJVwlpgdSai9K+vE=",
      "url": "index.html"
    },
    {
      "hash": "sha256-nVexsRC76y9Gxrx8qKNQx9JmKP4s4+Lc6oPAuLWO8tU=",
      "url": "js\/prism-bridge.js"
    },
    {
      "hash": "sha256-rbNnmZ4aDC1dw671mZGsxvyzZhIUnjxfXdDOybEBpgk=",
      "url": "js\/prism.js"
    },
    {
      "hash": "sha256-YM5hwS6ZptTDNeJJrDpu+DpXHjtrT0oLIzV8sGlNfZw=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yzFf+O\/mlH+Q9klUSqXP2kxGKOUFLPxaww8da8fKhGU=",
      "url": "sample-data\/weather.json"
    },
    {
      "hash": "sha256-O64ckIHPyi7yIVso8u\/ZGhkdQhw044ijAk21oPvQsHY=",
      "url": "_framework\/_bin\/Microsoft.DevSkim.Blazor.dll"
    },
    {
      "hash": "sha256-v9hqjeDfOD2PDb\/OCovfGtSiAmQGcvFuNrYYv7+8CT0=",
      "url": "_framework\/_bin\/Microsoft.DevSkim.dll"
    },
    {
      "hash": "sha256-mRd6TL4DYldo1ko9czkjEDcoiPdMPrJxz3dekwV6OOY=",
      "url": "_framework\/_bin\/Newtonsoft.Json.dll"
    },
    {
      "hash": "sha256-\/zcPVM75OAY+joGVM8yIC1gO1SFYWP1CFERgQ8PJkfA=",
      "url": "_framework\/_bin\/netstandard.dll"
    },
    {
      "hash": "sha256-IPbQMdJxZXdk8HTlaPyXdQ6Zb82iZLphnM74yO4EURQ=",
      "url": "_framework\/_bin\/System.Xml.Linq.dll"
    },
    {
      "hash": "sha256-Zw2\/5aDWjgMedporhjigwhi\/UCLcfl0tfa0LXUyD9HE=",
      "url": "_framework\/_bin\/System.Core.dll"
    },
    {
      "hash": "sha256-r6QdEXq0KfB8oZDzhnV4xskSbzJA0yBVi6XFpa3TGHM=",
      "url": "_framework\/_bin\/System.dll"
    },
    {
      "hash": "sha256-ob5gN\/szfb1CwWnyQWvWvuid3u4df593KvZeoJQEaKc=",
      "url": "_framework\/_bin\/WebAssembly.Net.WebSockets.dll"
    },
    {
      "hash": "sha256-\/cPXlNTX8GKF\/lIn\/2DIjtxTe0Wpy4ZDcyAj67b6JYk=",
      "url": "_framework\/_bin\/System.Memory.dll"
    },
    {
      "hash": "sha256-BaZPMj95+YNe3G4ckTGD6szZFwZeA2MOHn91zTGKDeU=",
      "url": "_framework\/_bin\/mscorlib.dll"
    },
    {
      "hash": "sha256-6XMT1eT3svGdg6hFzAHJscYdTQjakoYccYTdHmKSr7Y=",
      "url": "_framework\/_bin\/WebAssembly.Bindings.dll"
    },
    {
      "hash": "sha256-8g0neeYVmPrxWgbMI0ZTVO6257qMisUTPZ78egAnIMw=",
      "url": "_framework\/_bin\/System.Numerics.dll"
    },
    {
      "hash": "sha256-RMOYBniHZkD8OZrBV3ONIMTZqsBhSAcBFm4pVuY9dv4=",
      "url": "_framework\/_bin\/System.Xml.dll"
    },
    {
      "hash": "sha256-fMngt4py0YmfHqV6eONyCI6R5m+YOE7KZ3U4MzCrskE=",
      "url": "_framework\/_bin\/Mono.Security.dll"
    },
    {
      "hash": "sha256-VAHA4LWcsdHUBgFG1\/xwhc4IyJ0ZH9UyK9+qSPzDa6Y=",
      "url": "_framework\/_bin\/System.Transactions.dll"
    },
    {
      "hash": "sha256-C09aqx1vDLK7zQ9XnZcUqAgTDRwybxhRg\/FR8HSk1v8=",
      "url": "_framework\/_bin\/System.Runtime.Serialization.dll"
    },
    {
      "hash": "sha256-6mtLxbGMMGcIfch8cp0W9gmBoI493AxBRUPGEzOn3nU=",
      "url": "_framework\/_bin\/System.ServiceModel.Internals.dll"
    },
    {
      "hash": "sha256-moW4EYN6ExD6T0vSBMMggn62cZaTd8dSr9b\/yj\/9dPM=",
      "url": "_framework\/_bin\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-LUtkiqNd5ABTiuiYaqzaJxVjPq+Z4FqezuIWk\/faqSA=",
      "url": "_framework\/_bin\/System.Net.Http.WebAssemblyHttpHandler.dll"
    },
    {
      "hash": "sha256-R8CUbbWAKar388eFQJhUgiTgLEv2Mih9wr9iO0P7ImU=",
      "url": "_framework\/_bin\/System.ComponentModel.Composition.dll"
    },
    {
      "hash": "sha256-ptCMHBy9q8MMLU0ukLMuvvhQk\/yYljw37MTKtfsvuFQ=",
      "url": "_framework\/_bin\/System.IO.Compression.FileSystem.dll"
    },
    {
      "hash": "sha256-hLbkXBzxUk9DSXYTLGRowe+80rxmpXsqEZbPIL4+5zs=",
      "url": "_framework\/_bin\/System.IO.Compression.dll"
    },
    {
      "hash": "sha256-vcCLMX4xAsUqKuQjjIkzu1O9pHGO\/tdvysgSmEjL6oo=",
      "url": "_framework\/_bin\/System.Drawing.Common.dll"
    },
    {
      "hash": "sha256-eejp4oI3sQBq\/tI6GsJNaPu3Dkdot5Vbn8+R3w2vYLE=",
      "url": "_framework\/_bin\/System.Data.DataSetExtensions.dll"
    },
    {
      "hash": "sha256-dxfTuT6ffPMmvuUUTfv7+bpLtOZZZHQdz77hjhy9qHw=",
      "url": "_framework\/_bin\/System.Data.dll"
    },
    {
      "hash": "sha256-CCcLoUROc5qeK\/1UNVb\/AC6\/au9JUZ6zZVNzyOnIa7I=",
      "url": "_framework\/_bin\/MoreLinq.dll"
    },
    {
      "hash": "sha256-Bs1Wrmh4ex9dTEIT0yCRF52N\/wOmsBDt457BHr0\/ssM=",
      "url": "_framework\/_bin\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-LqwA2Rpm96Ualk0IhLZar87kfRCyKHzHTeTt2jYhm7M=",
      "url": "_framework\/_bin\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-Tqh1Da+iTRQJEZUGAsMNFuZ4hf1PMf13WApRZod+uw4=",
      "url": "_framework\/_bin\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-HQeN+ZfHAERO+uW0fP0J9J3WV1hQ3vUIOWbqGSYBPp8=",
      "url": "_framework\/_bin\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-kL\/omZDwqByAi+lPdMeDmr3XjHcn4RVb+LmZ4mut1Yc=",
      "url": "_framework\/_bin\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-ZxXy75PYbzJxNfAc\/SAP1nUYm4gt1jSaOpFnBb9m85M=",
      "url": "_framework\/_bin\/System.Buffers.dll"
    },
    {
      "hash": "sha256-OBWh2or+2mU6elwqPfmL72FBZVKl2WzTJ4L\/IrKeXM4=",
      "url": "_framework\/_bin\/Microsoft.Bcl.AsyncInterfaces.dll"
    },
    {
      "hash": "sha256-TkH6yxFQlTfY8NfznePrCdYJiEVpM9Dqy4Uu4H9qk10=",
      "url": "_framework\/_bin\/System.Threading.Tasks.Extensions.dll"
    },
    {
      "hash": "sha256-qAKfFnquY+7UC\/MzLi04rjqEhLzTryCoLg\/S6MxI19I=",
      "url": "_framework\/_bin\/System.Numerics.Vectors.dll"
    },
    {
      "hash": "sha256-FG6nplF97w9zJVvhJ\/1rZ94zizmZikQYKkqU83S8R6o=",
      "url": "_framework\/_bin\/Sarif.dll"
    },
    {
      "hash": "sha256-LwWixInC0wpsyjRtTOGEMj1w609a+mvtNNWAAnRETlc=",
      "url": "_framework\/_bin\/System.Collections.Immutable.dll"
    },
    {
      "hash": "sha256-ZZG2J0x6eJNs2qd0n1LTf\/r4bDPHIBhsdhVS1PG2UiM=",
      "url": "_framework\/_bin\/devskim.dll"
    },
    {
      "hash": "sha256-NuNZEoM8oRyCNKbIh0usD6A9pqHx+wEoEYAyckX5QY8=",
      "url": "_framework\/_bin\/RecursiveExtractor.dll"
    },
    {
      "hash": "sha256-kZPgI2yYlPuvK0CXzPVfDXu7kpYIOXkTJ4wkGJvCT5Y=",
      "url": "_framework\/_bin\/DiscUtils.Streams.dll"
    },
    {
      "hash": "sha256-Ov35b6lw0Uu4d7AUiso54Pn52atsZfpdzbRuWnuvpEc=",
      "url": "_framework\/_bin\/DiscUtils.Xfs.dll"
    },
    {
      "hash": "sha256-LYSzGwAdEHNsFQFH258fnH\/NcTtGG9unHyymHyiDcvs=",
      "url": "_framework\/_bin\/DiscUtils.Core.dll"
    },
    {
      "hash": "sha256-A4+6\/yKbXS2vs7Vr1quzSX26JTW4l3sDC1EazeKyye0=",
      "url": "_framework\/_bin\/System.Text.Encoding.CodePages.dll"
    },
    {
      "hash": "sha256-NFuj\/W4EdWMh3YIvij0lZeWdQJ7POvm\/Tx3bcT2wyis=",
      "url": "_framework\/_bin\/System.Security.AccessControl.dll"
    },
    {
      "hash": "sha256-\/oW2BNlB4HW16Pus6QKV8bpNI1cjQ4psfHmnZ+TiREw=",
      "url": "_framework\/_bin\/DiscUtils.Ntfs.dll"
    },
    {
      "hash": "sha256-O1xfFIXp6Syz5e2YKz156XDI48LLpDEUDKJFLXWaZkE=",
      "url": "_framework\/_bin\/System.Security.Principal.Windows.dll"
    },
    {
      "hash": "sha256-5vgHQSjwJP98ROPlEFJllolHr7WvHNdrMhyEDEECz4M=",
      "url": "_framework\/_bin\/DiscUtils.HfsPlus.dll"
    },
    {
      "hash": "sha256-fscx4W6gcQ2igZXtqPETBwngrUMBCkvAsqUpdVYtzeA=",
      "url": "_framework\/_bin\/DiscUtils.Fat.dll"
    },
    {
      "hash": "sha256-UxQNz63zPkV+MdGFsOIKk\/vnygy+fa1ufsRay7ImNVc=",
      "url": "_framework\/_bin\/DiscUtils.Ext.dll"
    },
    {
      "hash": "sha256-auY8l+KHhDlo8+JzvvP3Pfod69HcEUx+cx2zZyZrpOI=",
      "url": "_framework\/_bin\/DiscUtils.Btrfs.dll"
    },
    {
      "hash": "sha256-LIgg0eeN\/WKIEI3y6bt\/51WZtxgWFawcaDrta001Zh4=",
      "url": "_framework\/_bin\/lzo.net.dll"
    },
    {
      "hash": "sha256-zWDzFtXZzC+KLMGVRm7c4nLj3X7VnzT9SMdxCVqb3dE=",
      "url": "_framework\/_bin\/System.Collections.dll"
    },
    {
      "hash": "sha256-CWadMXLl7iJZmsOz7PzKreH2b5rpyAFY8KYvg17YAv8=",
      "url": "_framework\/_bin\/System.IO.dll"
    },
    {
      "hash": "sha256-6CpyRQAYrVPJfNYBKH0K9lWX+rNPO15lwNhGHPmvxtk=",
      "url": "_framework\/_bin\/System.Runtime.dll"
    },
    {
      "hash": "sha256-AJVG0X9kjUnQt9NOiQzUQGksS5K0j+ltGDTQBTlK1ks=",
      "url": "_framework\/_bin\/DiscUtils.Wim.dll"
    },
    {
      "hash": "sha256-sTdmk+fX0pJCLlRb29YRPX94eTy+RYfTCmy2iu+P80U=",
      "url": "_framework\/_bin\/DiscUtils.Vmdk.dll"
    },
    {
      "hash": "sha256-ikgDHxpu+OuwmjMB+so7d1u09Qd6MUkMFagqUtaBhyw=",
      "url": "_framework\/_bin\/DiscUtils.Vhdx.dll"
    },
    {
      "hash": "sha256-nT8UmJS5ROF+eNo5Hs9UkjMBK7WjLi8KlMY\/i5DE\/Ao=",
      "url": "_framework\/_bin\/DiscUtils.Vhd.dll"
    },
    {
      "hash": "sha256-qkKLqTvSQjFyGVJkXLJhIT3HQd\/X2Cq61e++5wfN\/eA=",
      "url": "_framework\/_bin\/DiscUtils.Iso9660.dll"
    },
    {
      "hash": "sha256-z8SMI+GbLh5Vnmm6uqlRU38p01r+BW2oS0YRUn5a4B0=",
      "url": "_framework\/_bin\/ICSharpCode.SharpZipLib.dll"
    },
    {
      "hash": "sha256-v5QABc0sir8R7Fm5r1AbF4rKoF33FYXnKpZ7RzToLUo=",
      "url": "_framework\/_bin\/SharpCompress.dll"
    },
    {
      "hash": "sha256-19lvGOo6Jw3E66nkKX6tW+BtuK170gZTylZVELVXrU8=",
      "url": "_framework\/_bin\/NLog.dll"
    },
    {
      "hash": "sha256-c9MKB9pGqlFWp6sSIc2ITkdvMsGSGbrRnHzBIBtlIHI=",
      "url": "_framework\/_bin\/Microsoft.Extensions.CommandLineUtils.dll"
    },
    {
      "hash": "sha256-egPOud7Mcxx\/20iAZiekEmazNYxAwi8HO1Z5+a4Ikww=",
      "url": "_framework\/_bin\/System.Linq.dll"
    },
    {
      "hash": "sha256-dqzLPW8oFg5YVC2+79UXgMTdvPsrnepDLYkV0Ipnmbo=",
      "url": "_framework\/_bin\/System.Threading.Tasks.dll"
    },
    {
      "hash": "sha256-WOuyyXorC98FVmPBn89B4UpQzNRD00zIT5xtbn+Q7Bg=",
      "url": "_framework\/_bin\/System.Console.dll"
    },
    {
      "hash": "sha256-U4q43ZeuBEBaCygKJwr18fjDYwnFv22MHuvMVqnpNzI=",
      "url": "_framework\/_bin\/System.Resources.ResourceManager.dll"
    },
    {
      "hash": "sha256-7+FtaZd2xSysaMLC59XhYdtkNMZ15ha0lk73dxPdT5w=",
      "url": "_framework\/_bin\/Blazored.LocalStorage.dll"
    },
    {
      "hash": "sha256-rvTW0d54uLW0iDMAX30lpmr9f8uHoS3YYkEU5zNGhyc=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-y\/FyJQOcW2TOcTp7Iuv8brGBzL5ZP0oJdG7ysK+gtKc=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-bSgsT2x5xMvs8mara5wU+EJwcyHa9GVMU85HwhWcdWM=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-m7Q+cF5\/ji3OMfdGlCuE8pQ\/iM+kxNHLq\/IEWVvIaOg=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.Forms.dll"
    },
    {
      "hash": "sha256-tmnkCmP9OzLUkpQ3LP7PRosi7gt5pyfEZCM6aqAokFI=",
      "url": "_framework\/_bin\/System.ComponentModel.Annotations.dll"
    },
    {
      "hash": "sha256-LIfCYwg+PHltTK4z3EnbSkA7m2cn8JS4jHVthdKrDF8=",
      "url": "_framework\/_bin\/System.ComponentModel.DataAnnotations.dll"
    },
    {
      "hash": "sha256-PEg9ghiKSWBTX0jq8pFDvv2Yvw92Y8W0ELtWrSE4fhA=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-6gJMwefpsWLHWsEipZp143xn8k2Ea27upnXqjUT6iNI=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-+8JsYr0nQtK1U5Ora9CZpNOUQSOY7TzFoOmWTAOtAW4=",
      "url": "_framework\/_bin\/Tewr.Blazor.FileReader.dll"
    },
    {
      "hash": "sha256-FJ+rEgcx6ljTxwbRXZSUGfrDKpVvOxHCSfNxbnXNn3M=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-oK1Bjv95fH+hSbogUkJE+xDAI203kJG6lL6Sm\/NuPWg=",
      "url": "_framework\/_bin\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-n0Ag7rF7ZQamklPSZkakIXkRoa6JwlmPSS0cRaAhJQM=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-2jNkt\/\/JGfoqWNB8whRdJotnsanWbH3FfxZWz0gyLTs=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-mQqyOIjuVduaLQ7ZyvDrChDLp8rTeQknIIWDzqsO4eY=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-3trD3kyUrc0a2IrNSfLT2rSZ35MMdD2qtqG+vk+U8QA=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.FileExtensions.dll"
    },
    {
      "hash": "sha256-tY1dlliVr+yGzBF7d0z\/iaulZfBJNaSrCKDD0RP2cc8=",
      "url": "_framework\/_bin\/Microsoft.Extensions.FileProviders.Physical.dll"
    },
    {
      "hash": "sha256-r8LuqDQgcB\/c3E48xHqsAY1eRZB1ZtuqZF6nlufn7kg=",
      "url": "_framework\/_bin\/Microsoft.Extensions.FileSystemGlobbing.dll"
    },
    {
      "hash": "sha256-DrtNiKIMjfSOdamH5Bs5zHmjFADgNiwrY5tRgTm6XuI=",
      "url": "_framework\/_bin\/Microsoft.Extensions.FileProviders.Abstractions.dll"
    },
    {
      "hash": "sha256-+kkwUt5LUrFrnFcHiSvLP3Ps50UAimB6C5utgehqOo4=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-czNf3btAeBW\/vvID5LAfgcsNZ+GM3ssVuPaMflcg0rs=",
      "url": "_framework\/_bin\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-kL\/4RcUAZaVE2igMIDV\/xKYuZ0P8ukB6LIXNpaN+9jA=",
      "url": "_framework\/_bin\/Microsoft.DevSkim.Blazor.pdb"
    },
    {
      "hash": "sha256-Xvy\/COLebvFpYan5Y196ZP2aNunHdo\/Z4lgWqo56tXU=",
      "url": "_framework\/_bin\/Microsoft.DevSkim.pdb"
    },
    {
      "hash": "sha256-XdXdgRpFq4GyCWpXzlfuR9TwOp8lrChW1Bo5A7Ftnww=",
      "url": "_framework\/_bin\/MoreLinq.pdb"
    },
    {
      "hash": "sha256-tS\/\/Txy6j39tDHTrRd7neEcX\/02ROAKdP108Oxxf3Ts=",
      "url": "_framework\/_bin\/devskim.pdb"
    },
    {
      "hash": "sha256-he925pOkmKA76ZzQ65k\/CJuKDFB8oZb0qiZ8x8c7sLA=",
      "url": "_framework\/_bin\/ICSharpCode.SharpZipLib.pdb"
    },
    {
      "hash": "sha256-mPoqx7XczFHBWk3gRNn0hc9ekG1OvkKY4XiKRY5Mj5U=",
      "url": "_framework\/wasm\/dotnet.3.2.0.js"
    },
    {
      "hash": "sha256-3S0qzYaBEKOBXarzVLNzNAFXlwJr6nI3lFlYUpQTPH8=",
      "url": "_framework\/wasm\/dotnet.timezones.dat"
    },
    {
      "hash": "sha256-UC\/3Rm1NkdNdlIrzYARo+dO\/HDlS5mhPxo0IQv7kma8=",
      "url": "_framework\/wasm\/dotnet.wasm"
    },
    {
      "hash": "sha256-SPHS1EAPAcMFN4TEIUYl3FWtoCQTsNJch0XVGgok1eE=",
      "url": "_framework\/blazor.webassembly.js"
    },
    {
      "hash": "sha256-mykkZv2h9oe846UJ3yZ1lJwErceqYir8WFQRmPK4ysg=",
      "url": "_framework\/blazor.boot.json"
    }
  ],
  "version": "6ricKBD+"
};
